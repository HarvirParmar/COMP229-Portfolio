
import dotenv from 'dotenv';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { MongoClient, ObjectId } from 'mongodb';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

dotenv.config({
  path: path.join(path.dirname(fileURLToPath(import.meta.url)), '.env')
});

const app = express();
app.use(express.json());

const client = new MongoClient(process.env.MONGO_URI);
let db;

const allowedCollections = [
  'contacts',
  'projects',
  'qualifications',
  'users'
];

function authenticateToken(req, res, next) {
  const header = req.headers.authorization;
  const token = header?.startsWith('Bearer ')
    ? header.slice(7)
    : null;

  if (!token) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(403).json({ error: 'Invalid or expired token' });
  }
}

app.get('/', (req, res) => {
  res.send('Welcome to my Portfolio API');
});

app.post('/api/auth/signup', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        error: 'Name, email, and password are required'
      });
    }

    const users = db.collection('users');
    const existingUser = await users.findOne({ email });

    if (existingUser) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const now = new Date();

    const result = await users.insertOne({
      name,
      email,
      password: hashedPassword,
      created: now,
      updated: now
    });

    return res.status(201).json({
      message: 'Account created',
      userId: result.insertedId
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post('/api/auth/signin', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        error: 'Email and password are required'
      });
    }

    const user = await db.collection('users').findOne({ email });

    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const token = jwt.sign(
      { userId: user._id.toString(), email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: '2h' }
    );

    return res.json({
      message: 'Sign-in successful',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email
      }
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.post('/api/auth/signout', authenticateToken, (req, res) => {
  res.json({ message: 'Sign out by deleting your stored token' });
});

app.use('/api', authenticateToken);

app.all('/api/:collection', async (req, res) => {
  const name = req.params.collection;

  if (!allowedCollections.includes(name)) {
    return res.status(404).json({ error: 'Collection not found' });
  }

  try {
    const collection = db.collection(name);

    if (req.method === 'GET') {
      return res.json(await collection.find({}).toArray());
    }

    if (req.method === 'POST') {
      const result = await collection.insertOne(req.body);
      return res.status(201).json(result);
    }

    if (req.method === 'DELETE') {
      const result = await collection.deleteMany({});
      return res.json(result);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.all('/api/:collection/:id', async (req, res) => {
  const name = req.params.collection;
  const id = req.params.id;

  if (!allowedCollections.includes(name)) {
    return res.status(404).json({ error: 'Collection not found' });
  }

  if (!ObjectId.isValid(id)) {
    return res.status(400).json({ error: 'Invalid ID' });
  }

  try {
    const collection = db.collection(name);
    const filter = { _id: new ObjectId(id) };

    if (req.method === 'GET') {
      const result = await collection.findOne(filter);
      return result
        ? res.json(result)
        : res.status(404).json({ error: 'Record not found' });
    }

    if (req.method === 'PUT') {
      const result = await collection.updateOne(filter, {
        $set: { ...req.body, updated: new Date() }
      });
      return res.json(result);
    }

    if (req.method === 'DELETE') {
      const result = await collection.deleteOne(filter);
      return res.json(result);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

async function startServer() {
  if (!process.env.MONGO_URI) {
    throw new Error('MONGO_URI is missing from .env');
  }

  if (!process.env.JWT_SECRET) {
    throw new Error('JWT_SECRET is missing from .env');
  }

  await client.connect();
  db = client.db('Portfolio');

  console.log('Connected to MongoDB');

  app.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
  });
}

startServer().catch((error) => {
  console.error('Server startup failed:', error.message);
});
